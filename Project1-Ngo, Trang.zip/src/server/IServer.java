package server;

/*
  Server interface
 */
public interface IServer {
  void start() throws Exception;
}
