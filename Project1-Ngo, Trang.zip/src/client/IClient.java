package client;

import java.io.IOException;

// Interface for client
public interface IClient {
  void start() throws IOException;
}
